<?php

require_once('config.php');
$allowedExts = array("gif", "jpeg", "jpg", "png", "exe", "gzip","zip","docx","doc","txt","pdf");
$temp = explode(".", $_FILES["file"]["name"]);
$extension = end($temp);
$idaluno=$_POST['idaluno_upload'];

//echo $_FILES["file"]["type"];die;
//echo $_FILES["file"]["size"];die;
//if ((($_FILES["file"]["type"] == "image/gif")
//        || ($_FILES["file"]["type"] == "image/jpeg") 
//        || ($_FILES["file"]["type"] == "application/pdf")         
//        || ($_FILES["file"]["type"] == "application/octet-stream")         
//        || ($_FILES["file"]["type"] == "application/x-msdownload") 
//        || ($_FILES["file"]["type"] == "image/jpg")
//        || ($_FILES["file"]["type"] == "image/pjpeg") 
//        || ($_FILES["file"]["type"] == "image/x-png") 
//        || ($_FILES["file"]["type"] == "image/png")
//        ) 
//        && ($_FILES["file"]["size"] < 200000000) && in_array($extension, $allowedExts)) {
  
  if (($_FILES["file"]["size"] < 200000000) && in_array($extension, $allowedExts)) {
  
  if ($_FILES["file"]["error"] > 0) {
    echo "Return Code: " . $_FILES["file"]["error"] . "<br>";
  }
  else {

    if (file_exists("upload/" . $_FILES["file"]["name"])) {
      echo $_FILES["file"]["name"] . " já existe exists. ";
    }
    else {
      move_uploaded_file($_FILES["file"]["tmp_name"], dir_arquivos .$idaluno.'_'.$_FILES["file"]["name"]);
      insere_arquivo($idaluno.'_'.$_FILES["file"]["name"],$idaluno);
      //echo "enviado na pasta: " . dir_arquivos . $idaluno.'_'.$_FILES["file"]["name"];
    }
  }
}
else {
  echo "Arquivo Invalido";
}

function insere_arquivo($caminho,$idaluno) {
    $conn = mysqli_connect(db_host, db_user, db_pass, db_base);
    $sql = "delete from arquivos where idaluno =". $idaluno." and caminho='".$caminho."'";
    mysqli_query($conn, $sql);
    $sql = "insert into arquivos (caminho,idaluno)       values ('" . $caminho . "',              '". $idaluno."'             )";
    mysqli_query($conn, $sql);
    mysqli_close($conn);  
}

;
?>
