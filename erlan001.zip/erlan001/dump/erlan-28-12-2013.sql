-- --------------------------------------------------------
-- Servidor:                     127.0.0.1
-- Versão do servidor:           5.5.24-log - MySQL Community Server (GPL)
-- OS do Servidor:               Win32
-- HeidiSQL Versão:              8.1.0.4545
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Copiando estrutura para tabela erlan001.alunos
CREATE TABLE IF NOT EXISTS `alunos` (
  `idaluno` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(50) DEFAULT NULL,
  `sobrenome` varchar(50) DEFAULT NULL,
  `data_cadastro` date DEFAULT NULL,
  `data_nascimento` date DEFAULT NULL,
  `data_treinamento` date DEFAULT NULL,
  `cpf` varchar(50) DEFAULT NULL,
  `cargo` varchar(50) DEFAULT NULL,
  `codParceiro` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`idaluno`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

-- Copiando dados para a tabela erlan001.alunos: ~4 rows (aproximadamente)
DELETE FROM `alunos`;
/*!40000 ALTER TABLE `alunos` DISABLE KEYS */;
INSERT INTO `alunos` (`idaluno`, `nome`, `sobrenome`, `data_cadastro`, `data_nascimento`, `data_treinamento`, `cpf`, `cargo`, `codParceiro`) VALUES
	(4, 'Fabio', 'Pereira', '2013-12-03', '1979-04-10', '2013-12-17', '26721993880', 'Programador', '888'),
	(5, 'Fabio', 'Pereira', '2013-12-26', '2013-12-26', '2013-12-26', '26721993880', 'Programador', '888'),
	(6, 'Fabio', 'Pereira', '2013-12-26', '2013-12-26', '2013-12-26', '26721993880', 'Programador', '888'),
	(11, 'Fabio Alvaro', 'Pereira', '2013-12-01', '2013-12-08', '2013-12-15', '26721993880', 'Programador', '7777');
/*!40000 ALTER TABLE `alunos` ENABLE KEYS */;


-- Copiando estrutura para tabela erlan001.arquivos
CREATE TABLE IF NOT EXISTS `arquivos` (
  `idarquivo` int(11) NOT NULL AUTO_INCREMENT,
  `caminho` varchar(50) DEFAULT NULL,
  `idaluno` int(11) DEFAULT NULL,
  PRIMARY KEY (`idarquivo`)
) ENGINE=InnoDB AUTO_INCREMENT=81 DEFAULT CHARSET=latin1;

-- Copiando dados para a tabela erlan001.arquivos: ~5 rows (aproximadamente)
DELETE FROM `arquivos`;
/*!40000 ALTER TABLE `arquivos` DISABLE KEYS */;
INSERT INTO `arquivos` (`idarquivo`, `caminho`, `idaluno`) VALUES
	(76, '11_npp.6.5.2.Installer.exe', 11),
	(77, '11_TELA INICIAL1.0.pdf', 11),
	(78, '11_admin_menu-6.x-1.8.doc', 11),
	(79, '11_devel_info-6.x-1.0.docx', 11),
	(80, '11_devel-6.x-1.27.txt', 11);
/*!40000 ALTER TABLE `arquivos` ENABLE KEYS */;


-- Copiando estrutura para tabela erlan001.usuarios
CREATE TABLE IF NOT EXISTS `usuarios` (
  `idusuario` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(50) DEFAULT NULL,
  `senha` varchar(50) DEFAULT NULL,
  `tipo` varchar(1) DEFAULT NULL,
  `codParceiro` varchar(50) NOT NULL DEFAULT '0',
  PRIMARY KEY (`idusuario`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

-- Copiando dados para a tabela erlan001.usuarios: ~2 rows (aproximadamente)
DELETE FROM `usuarios`;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` (`idusuario`, `nome`, `senha`, `tipo`, `codParceiro`) VALUES
	(14, 'fabio', 'teste123', 'C', '7777'),
	(15, 'isabela', 'teste123', 'U', '8888');
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
